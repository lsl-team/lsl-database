from django.apps import AppConfig


class ArtConfig(AppConfig):
    name = 'art'
